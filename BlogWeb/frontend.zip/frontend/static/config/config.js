window.global = {
  ApiUrl: 'http://128.199.253.108:9000/',
  TimeOut: 10000,
  ExportTaskTotal: 100000,
  db_prefix: 'Layered_Map',
  Title: 'VUEDemo',
  SecDirectory: '/',
  defaultPage: '/home',
  Copyright: 'KanadeM©2019'
}
